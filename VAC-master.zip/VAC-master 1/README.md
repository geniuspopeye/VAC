# VAC
Project for discrete math colloquium
