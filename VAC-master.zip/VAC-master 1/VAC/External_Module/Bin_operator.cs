﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace External_module
{
    public class Bin_operator : Operators
    {
        public Bin_operator() : base()
        {
            count_of_up_connection = 2;
        }
    }
}
