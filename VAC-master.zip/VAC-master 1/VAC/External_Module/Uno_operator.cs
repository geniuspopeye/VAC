﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace External_module
{
    public class Uno_operator : Operators
    {
        public Uno_operator() :base()
        {
            count_of_up_connection = 1;
        }
    }
}
